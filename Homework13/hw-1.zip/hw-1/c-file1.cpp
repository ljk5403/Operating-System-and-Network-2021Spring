#include "speak.h"
#include<iostream>
using namespace std;

int main(){
    Speak a;
    a.sayHello();
    return 0;
}