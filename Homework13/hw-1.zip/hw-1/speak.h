class Speak{
    public:
    void sayHello();
};