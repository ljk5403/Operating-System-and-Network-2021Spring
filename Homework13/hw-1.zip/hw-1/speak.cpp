#include "speak.h"
#include<iostream>
using namespace std;
void Speak::sayHello(){
  cout<<"Hello"<<endl;
}
